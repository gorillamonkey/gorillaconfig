<?php


//gorilla monkey configuration setup

// gorilla monkey //

class setup{
public $localhost = "127.0.0.1";
public $port = "";
public $dbname = " webpress_users";
public $pass = "root";
public $username = "root";
}


$pconnect = new setup();
// installation setup process
$lo = $pconnect -> localhost;
$user = $pconnect -> username;
$pass = $pconnect -> pass;
$dbname = $pconnect -> dbname;
$port = $pconnect -> dbname;

//use this variable to your config.php

$localhost = $lo;
$username = $user;
$password = $pass;
$databaseName = $dbname;
$port = $port;
// rendering  code for your config.php

$localhost;
$username;
$password;
$databaseName;
$port;

//google master for php


//implement this on normal config.php//